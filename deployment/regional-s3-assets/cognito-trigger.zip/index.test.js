"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("./index");
const aws_sdk_client_mock_1 = require("aws-sdk-client-mock");
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
describe("cognito-trigger", function () {
    let cognitoClientMock;
    beforeEach(() => {
        cognitoClientMock = (0, aws_sdk_client_mock_1.mockClient)(client_cognito_identity_provider_1.CognitoIdentityProviderClient);
        cognitoClientMock.on(client_cognito_identity_provider_1.AdminAddUserToGroupCommand).resolves();
    });
    it("should add federated users to ReadOnlyUserGroup", function () {
        return __awaiter(this, void 0, void 0, function* () {
            // given
            const event = {
                userPoolId: "user-pool-id",
                userName: "user-name",
                triggerSource: "PostConfirmation_ConfirmSignUp",
                region: "us-east-1",
                request: {
                    userAttributes: {
                        "cognito:user_status": "EXTERNAL_PROVIDER",
                        email_verified: "false",
                        identities: "",
                        sub: "user-uuid",
                    },
                },
            };
            // when
            yield (0, index_1.handler)(event);
            // then
            expect(cognitoClientMock.calls()).toHaveLength(1);
            let command = cognitoClientMock.call(0).firstArg;
            expect(command).toBeInstanceOf(client_cognito_identity_provider_1.AdminAddUserToGroupCommand);
            expect(command.input).toEqual({
                "UserPoolId": event.userPoolId,
                "Username": event.userName,
                "GroupName": index_1.READ_ONLY_USER_GROUP
            });
        });
    });
    it("should not call Cognito for non federated users", function () {
        return __awaiter(this, void 0, void 0, function* () {
            // given
            const event = {
                userPoolId: "user-pool-id",
                userName: "user-name",
                triggerSource: "trigger-src",
                region: "us-east-1",
                request: {
                    userAttributes: {
                        "cognito:user_status": "CONFIRMED",
                        email_verified: "false",
                        identities: "",
                        sub: "user-uuid",
                    },
                },
            };
            // when
            yield (0, index_1.handler)(event);
            // then
            expect(cognitoClientMock.calls()).toHaveLength(0);
        });
    });
});
//# sourceMappingURL=index.test.js.map