"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.READ_ONLY_USER_GROUP = void 0;
const logger_1 = require("./lib/logger");
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
function isExternalUserLoggingInForTheFirstTime(event) {
    return event.triggerSource === "PostConfirmation_ConfirmSignUp" &&
        event.request.userAttributes["cognito:user_status"] ===
            "EXTERNAL_PROVIDER";
}
exports.READ_ONLY_USER_GROUP = 'ReadOnlyUserGroup'; // GroupName of UserPoolGroupReadOnlyUsers from cf template
function addUserToReadOnlyUserGroup(event) {
    return __awaiter(this, void 0, void 0, function* () {
        logger_1.logger.debug("Handling federated user");
        const userAgent = [[`AWSSOLUTION/${process.env.SOLUTION_ID || ''}`, `${process.env.SOLUTION_VERSION}` || '']];
        const configuration = { region: event.region, customUserAgent: userAgent };
        const client = new client_cognito_identity_provider_1.CognitoIdentityProviderClient(configuration);
        const command = new client_cognito_identity_provider_1.AdminAddUserToGroupCommand({
            UserPoolId: event.userPoolId,
            Username: event.userName,
            GroupName: exports.READ_ONLY_USER_GROUP
        });
        yield client.send(command);
    });
}
function handler(event) {
    return __awaiter(this, void 0, void 0, function* () {
        logger_1.logger.debug(`Received event: ${JSON.stringify(event, null, 2)}`);
        if (isExternalUserLoggingInForTheFirstTime(event)) {
            yield addUserToReadOnlyUserGroup(event);
        }
    });
}
exports.handler = handler;
//# sourceMappingURL=index.js.map