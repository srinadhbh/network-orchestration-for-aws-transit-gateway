"""Exposes version constant to avoid circular dependencies."""

VERSION = "2.25.0"
